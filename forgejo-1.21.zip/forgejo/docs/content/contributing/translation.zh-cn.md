---
date: "2023-05-25T00:00:00+02:00"
title: "翻译指南"
sidebar_position: 70
toc: true
draft: false
menu:
  sidebar:
    parent: "contributing"
    name: "翻译指南"
    sidebar_position: 70
    identifier: "translation-guidelines"
---

本页面用于提供一套通用规则，以确保翻译的一致性。

* [German](/de-de/übersetzungs-richtlinien/)
