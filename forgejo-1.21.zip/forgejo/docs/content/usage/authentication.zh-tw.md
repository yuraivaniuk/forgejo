---
date: "2016-12-01T16:00:00+02:00"
title: "認證"
slug: "authentication"
sidebar_position: 10
toc: false
draft: false
aliases:
  - /zh-tw/authentication
menu:
  sidebar:
    parent: "usage"
    name: "認證"
    sidebar_position: 10
    identifier: "authentication"
---

# 認證

## TBD
