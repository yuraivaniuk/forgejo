---
date: "2019-11-12T16:00:00+02:00"
title: "搜索"
slug: "search"
sidebar_position: 1
toc: false
draft: false
aliases:
  - /zh-cn/help/search
sitemap:
  priority : 1
layout: "search"
---

This file exists solely to respond to /search URL with the related `search` layout template.

No content shown here is rendered, all content is based in the template layouts/doc/search.html

Setting a very low sitemap priority will tell search engines this is not important content.
