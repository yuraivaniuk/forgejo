# Forgejo - Docker

The Dockerfile can be found in the root of repository. [Dockerfile](https://codeberg.org/forgejo/forgejo/src/branch/forgejo/Dockerfile) & [Dockerfile.rootless](https://codeberg.org/forgejo/forgejo/src/branch/forgejo/Dockerfile.rootless).

The Docker image can be found on [Coddeberg](https://codeberg.org/forgejo/-/packages/container/forgejo/).

Documentation on how you can use the docker image can be found on the [Forgejo documentation website](https://forgejo.org/docs/latest/admin/installation/#installation-with-docker).
